/*
 * BME280 Temperature Sensor Peripheral
 */
#include <zephyr/kernel.h>
#include <zephyr/device.h>
#include <zephyr/drivers/sensor.h>
#include <zephyr/drivers/i2c.h>

#include <zephyr/bluetooth/bluetooth.h>
#include <zephyr/bluetooth/uuid.h>
#include <zephyr/bluetooth/gatt.h>
#include <zephyr/bluetooth/hci.h>

#include <bluetooth/services/nus.h>
#include <dk_buttons_and_leds.h>

#include <stdio.h>
#include <string.h>

#include <zephyr/logging/log.h>

LOG_MODULE_REGISTER(bme280_ble, LOG_LEVEL_INF);

/* Get BME280 device */
static const struct device *bme280 = DEVICE_DT_GET(DT_ALIAS(bme280));

/* BLE Connection */
static struct bt_conn *current_conn;

#define DEVICE_NAME CONFIG_BT_DEVICE_NAME
#define DEVICE_NAME_LEN (sizeof(DEVICE_NAME) - 1)

#define CON_STATUS_LED DK_LED2

/* BLE Advertising Data */
static const struct bt_data ad[] = {
	BT_DATA_BYTES(BT_DATA_FLAGS, (BT_LE_AD_GENERAL | BT_LE_AD_NO_BREDR)),
	BT_DATA(BT_DATA_NAME_COMPLETE, DEVICE_NAME, DEVICE_NAME_LEN),
};

static const struct bt_data sd[] = {
	BT_DATA_BYTES(BT_DATA_UUID128_ALL, BT_UUID_NUS_VAL),
};

/* Connection Callbacks */
static void connected(struct bt_conn *conn, uint8_t err)
{
	char addr[BT_ADDR_LE_STR_LEN];

	if (err) {
		LOG_ERR("Connection failed (err %u)", err);
		return;
	}

	bt_addr_le_to_str(bt_conn_get_dst(conn), addr, sizeof(addr));
	LOG_INF("Connected %s", addr);

	current_conn = bt_conn_ref(conn);
	dk_set_led_on(CON_STATUS_LED);
}

static void disconnected(struct bt_conn *conn, uint8_t reason)
{
	char addr[BT_ADDR_LE_STR_LEN];

	bt_addr_le_to_str(bt_conn_get_dst(conn), addr, sizeof(addr));
	LOG_INF("Disconnected: %s (reason %u)", addr, reason);

	if (current_conn) {
		bt_conn_unref(current_conn);
		current_conn = NULL;
		dk_set_led_off(CON_STATUS_LED);
	}
}

BT_CONN_CB_DEFINE(conn_callbacks) = {
	.connected    = connected,
	.disconnected = disconnected,
};

/* NUS Receive Callback */
static void bt_receive_cb(struct bt_conn *conn, const uint8_t *const data, uint16_t len)
{
	LOG_INF("Received %d bytes", len);
}

static struct bt_nus_cb nus_cb = {
	.received = bt_receive_cb,
};

/* Read BME280 Temperature */
static int read_temperature(float *temp)
{
	struct sensor_value temperature;
	int ret;

	if (!device_is_ready(bme280)) {
		LOG_ERR("BME280 not ready!");
		return -ENODEV;
	}

	ret = sensor_sample_fetch(bme280);
	if (ret) {
		LOG_ERR("Sensor fetch failed: %d", ret);
		return ret;
	}

	ret = sensor_channel_get(bme280, SENSOR_CHAN_AMBIENT_TEMP, &temperature);
	if (ret) {
		LOG_ERR("Get temperature failed: %d", ret);
		return ret;
	}

	/* Convert to float */
	*temp = (float)temperature.val1 + ((float)temperature.val2 / 1000000.0f);
	
	return 0;
}

/* Send Temperature via BLE */
static void send_temperature(void)
{
	float temperature;
	char buffer[32];
	int ret;
	int temp_int;
	int temp_frac;

	/* Read sensor */
	ret = read_temperature(&temperature);
	if (ret) {
		LOG_ERR("Failed to read temperature");
		return;
	}

	/* Convert float to integer parts */
	temp_int = (int)temperature;
	temp_frac = (int)((temperature - temp_int) * 100);
	if (temp_frac < 0) temp_frac = -temp_frac;

	/* Format without using %f */
	snprintf(buffer, sizeof(buffer), "TEMP:%d.%02d\r\n", temp_int, temp_frac);

	/* Send via BLE */
	if (current_conn) {
		ret = bt_nus_send(current_conn, buffer, strlen(buffer));
		if (ret == 0) {
			LOG_INF("Sent: %s", buffer);
		} else {
			LOG_WRN("Send failed: %d", ret);
		}
	}
}

int main(void)
{
	int err;

	printk("\n\n=== BME280 BLE Peripheral ===\n\n");

	/* Initialize LEDs */
	err = dk_leds_init();
	if (err) {
		printk("LEDs init failed (err %d)\n", err);
	}

	/* Check BME280 */
	if (!device_is_ready(bme280)) {
		printk("ERROR: BME280 not ready!\n");
		printk("Check I2C wiring:\n");
		printk("  VCC -> 3.3V\n");
		printk("  GND -> GND\n");
		printk("  SDA -> P1.02\n");
		printk("  SCL -> P1.03\n");
		return 0;
	}
	printk("BME280 sensor ready\n");

	/* Test read */
	float test_temp;
	if (read_temperature(&test_temp) == 0) {
		int t_int = (int)test_temp;
		int t_frac = (int)((test_temp - t_int) * 100);
		printk("Test reading: %d.%02d C\n", t_int, t_frac);
	} else {
		printk("ERROR: Test read failed! Check sensor connection.\n");
	}

	/* Enable Bluetooth */
	err = bt_enable(NULL);
	if (err) {
		printk("Bluetooth init failed (err %d)\n", err);
		return 0;
	}
	printk("Bluetooth initialized\n");

	/* Initialize NUS */
	err = bt_nus_init(&nus_cb);
	if (err) {
		printk("NUS init failed (err %d)\n", err);
		return 0;
	}

	/* Start advertising */
	err = bt_le_adv_start(BT_LE_ADV_CONN, ad, ARRAY_SIZE(ad), sd, ARRAY_SIZE(sd));
	if (err) {
		printk("Advertising failed (err %d)\n", err);
		return 0;
	}

	printk("Advertising started - Device name: %s\n", DEVICE_NAME);
	printk("Waiting for connection...\n\n");

	/* Main loop - send every 2 seconds */
while (1)
{
    struct sensor_value temp;

    int ret = sensor_sample_fetch(bme280);
    if (ret != 0) {
        printk("Fetch error: %d\n", ret);
        k_sleep(K_SECONDS(2));
        continue;
    }

    sensor_channel_get(bme280, SENSOR_CHAN_AMBIENT_TEMP, &temp);

    int t_int = temp.val1;
    int t_frac = temp.val2 / 10000;
    if (t_frac < 0) t_frac = -t_frac;

    printk("Sensor raw: %d.%06d\n", temp.val1, temp.val2);

    char buffer[32];
    snprintf(buffer, sizeof(buffer), "TEMP:%d.%02d", t_int, t_frac);

    printk("Sent: %s\n", buffer);

    bt_nus_send(NULL, buffer, strlen(buffer));

    k_sleep(K_SECONDS(2));
}

	return 0;
}