/*
 * Central - BME280 Temperature Display on 16x2 LCD
 */
#include <zephyr/kernel.h>
#include <zephyr/device.h>
#include <zephyr/drivers/gpio.h>
#include <zephyr/drivers/i2c.h>
#include <zephyr/bluetooth/bluetooth.h>
#include <zephyr/bluetooth/conn.h>
#include <zephyr/bluetooth/uuid.h>
#include <zephyr/bluetooth/gatt.h>
#include <bluetooth/services/nus_client.h>
#include <bluetooth/scan.h>
#include <bluetooth/gatt_dm.h>
#include <dk_buttons_and_leds.h>

#include <stdio.h>
#include <string.h>

#include <zephyr/logging/log.h>
static float latest_temp = 0.0;
LOG_MODULE_REGISTER(central_temp, LOG_LEVEL_INF);

/* NUS Service UUID */
#define BT_UUID_NUS_VAL \
	BT_UUID_128_ENCODE(0x6e400001, 0xb5a3, 0xf393, 0xe0a9, 0xe50e24dcca9e)

#define BT_UUID_NUS_SERVICE BT_UUID_DECLARE_128(BT_UUID_NUS_VAL)

/* LCD I2C Configuration */
#define LCD_ADDR 0x27
static const struct device *i2c_dev;

/* NUS Client */
static struct bt_nus_client nus_client;
static struct bt_conn *current_conn;

/* Temperature storage */
static float current_temperature = 0.0f;

#define CON_STATUS_LED DK_LED2

/* ========== 16x2 LCD Driver - FIXED VERSION ========== */

#define LCD_BACKLIGHT 0x08
#define LCD_ENABLE    0x04
#define LCD_RW        0x02
#define LCD_RS        0x01

static void lcd_write_nibble(uint8_t nibble, uint8_t mode)
{
	uint8_t data = nibble | mode | LCD_BACKLIGHT;
	
	i2c_write(i2c_dev, &data, 1, LCD_ADDR);
	k_usleep(10);
	
	data |= LCD_ENABLE;
	i2c_write(i2c_dev, &data, 1, LCD_ADDR);
	k_usleep(10);
	
	data &= ~LCD_ENABLE;
	i2c_write(i2c_dev, &data, 1, LCD_ADDR);
	k_usleep(100);
}

static void lcd_write_byte(uint8_t data, uint8_t mode)
{
	lcd_write_nibble(data & 0xF0, mode);
	lcd_write_nibble((data << 4) & 0xF0, mode);
}

static void lcd_command(uint8_t cmd)
{
	lcd_write_byte(cmd, 0);
	k_msleep(5);
}

static void lcd_data(uint8_t data)
{
	lcd_write_byte(data, LCD_RS);
	k_usleep(100);
}

static void lcd_init(void)
{
	i2c_dev = DEVICE_DT_GET(DT_NODELABEL(i2c1));
	
	if (!device_is_ready(i2c_dev)) {
		printk("ERROR: I2C device not ready!\n");
		return;
	}
	
	printk("I2C ready, initializing LCD...\n");
	
	k_msleep(100);
	
	lcd_write_nibble(0x30, 0);
	k_msleep(10);
	
	lcd_write_nibble(0x30, 0);
	k_msleep(10);
	
	lcd_write_nibble(0x30, 0);
	k_msleep(10);
	
	lcd_write_nibble(0x20, 0);
	k_msleep(10);
	
	lcd_command(0x28);
	lcd_command(0x0C);
	lcd_command(0x01);
	k_msleep(10);
	lcd_command(0x06);
	
	printk("LCD initialized\n");
}

static void lcd_clear(void)
{
	lcd_command(0x01);
	k_msleep(10);
}

static void lcd_set_cursor(uint8_t row, uint8_t col)
{
	uint8_t row_offsets[] = {0x00, 0x40};
	lcd_command(0x80 | (col + row_offsets[row]));
	k_msleep(2);
}

static void lcd_print(const char *str)
{
	while (*str) {
		lcd_data(*str++);
	}
}

static void lcd_print_at(uint8_t row, uint8_t col, const char *str)
{
	lcd_set_cursor(row, col);
	lcd_print(str);
}

/* ========== BLE Code ========== */

static uint8_t nus_data_received(struct bt_nus_client *nus,
				 const uint8_t *data, uint16_t len)
{
	char temp_buffer[32];
	float temperature;
	printk("----\n");
printk("RAW LEN: %d\n", len);

for (int i = 0; i < len; i++) {
    printk("%02X ", data[i]);   // HEX print
}
printk("\n");

	printk("Len: %d\n", len);

	// ✅ Safe copy
	int copy_len = (len < sizeof(temp_buffer) - 1) ? len : sizeof(temp_buffer) - 1;
	memcpy(temp_buffer, data, copy_len);
	temp_buffer[copy_len] = '\0';

	// 🔥 DEBUG: हर character दिखाओ
	printk("RAW: ");
	for (int i = 0; i < copy_len; i++) {
		printk("%c", temp_buffer[i]);
	}
	printk("\n");

	// ✅ CLEAN STRING (IMPORTANT)
	for (int i = 0; i < copy_len; i++) {
		if (temp_buffer[i] == '\r' || temp_buffer[i] == '\n') {
			temp_buffer[i] = '\0';
			break;
		}
	}

	printk("Clean: [%s]\n", temp_buffer);

	// 🔥 BEST FIX: strstr + atof use करो (sscanf हटाओ)
char *ptr = strstr(temp_buffer, "TEMP:");
if (ptr != NULL) {

    int t_int = 0;
    int t_frac = 0;

    // 🔥 safe parsing (manual split)
    char *dot = strchr(ptr, '.');

    if (dot != NULL) {
        *dot = '\0';  // split string

        t_int = atoi(ptr + 5);
        t_frac = atoi(dot + 1);

        printk("Parsed Temp: %d.%02d\n", t_int, t_frac);

        char line1[17];
        char line2[17];

        snprintf(line1, sizeof(line1), "Connected");
        snprintf(line2, sizeof(line2), "Temp:%d.%02d C", t_int, t_frac);

        lcd_set_cursor(0, 0);
        lcd_print("                ");
        lcd_set_cursor(0, 0);
        lcd_print(line1);

        lcd_set_cursor(1, 0);
        lcd_print("                ");
        lcd_set_cursor(1, 0);
        lcd_print(line2);

    } else {
        printk("Dot not found!\n");
    }

} else {
    printk("TEMP not found!\n");
}
	return BT_GATT_ITER_CONTINUE;
}
static void nus_discovery_complete(struct bt_gatt_dm *dm, void *context)
{
	struct bt_nus_client *nus = context;
	int err;

	LOG_INF("NUS service discovered");
	bt_gatt_dm_data_print(dm);

	err = bt_nus_handles_assign(dm, nus);
	if (err) {
		LOG_ERR("Could not assign NUS handles (err %d)", err);
	}

	err = bt_nus_subscribe_receive(nus);
	if (err) {
		LOG_ERR("Could not subscribe to NUS (err %d)", err);
	} else {
		LOG_INF("Subscribed to NUS notifications");
	}

	bt_gatt_dm_data_release(dm);
}

static void nus_discovery_not_found(struct bt_conn *conn, void *context)
{
	LOG_WRN("NUS service not found");
}

static void nus_discovery_error(struct bt_conn *conn, int err, void *context)
{
	LOG_ERR("Discovery failed (err %d)", err);
}

static const struct bt_gatt_dm_cb nus_discovery_cb = {
	.completed = nus_discovery_complete,
	.service_not_found = nus_discovery_not_found,
	.error_found = nus_discovery_error,
};

static void connected(struct bt_conn *conn, uint8_t conn_err)
{
	char addr[BT_ADDR_LE_STR_LEN];
	int err;

	bt_addr_le_to_str(bt_conn_get_dst(conn), addr, sizeof(addr));

	if (conn_err) {
		LOG_ERR("Failed to connect to %s (err %d)", addr, conn_err);
		return;
	}

	LOG_INF("Connected: %s", addr);
	current_conn = bt_conn_ref(conn);
	dk_set_led_on(CON_STATUS_LED);

	lcd_clear();
	lcd_print_at(0, 0, "Connected!");
	k_msleep(1000);

	err = bt_gatt_dm_start(conn, BT_UUID_NUS_SERVICE, &nus_discovery_cb, &nus_client);
	if (err) {
		LOG_ERR("Failed to start discovery (err %d)", err);
	}
}

static void disconnected(struct bt_conn *conn, uint8_t reason)
{
	char addr[BT_ADDR_LE_STR_LEN];

	bt_addr_le_to_str(bt_conn_get_dst(conn), addr, sizeof(addr));
	LOG_INF("Disconnected: %s (reason %u)", addr, reason);
	dk_set_led_off(CON_STATUS_LED);

	lcd_clear();
	lcd_print_at(0, 0, "Disconnected");

	if (current_conn) {
		bt_conn_unref(current_conn);
		current_conn = NULL;
	}
}

BT_CONN_CB_DEFINE(conn_callbacks) = {
	.connected = connected,
	.disconnected = disconnected,
};

static void scan_filter_match(struct bt_scan_device_info *device_info,
			       struct bt_scan_filter_match *filter_match,
			       bool connectable)
{
	char addr[BT_ADDR_LE_STR_LEN];

	bt_addr_le_to_str(device_info->recv_info->addr, addr, sizeof(addr));
	LOG_INF("Device found: %s (RSSI %d)", addr, device_info->recv_info->rssi);
}

static void scan_connecting(struct bt_scan_device_info *device_info,
			    struct bt_conn *conn)
{
	LOG_INF("Connecting...");
	
	lcd_clear();
	lcd_print_at(0, 0, "Connecting...");
}

BT_SCAN_CB_INIT(scan_cb, scan_filter_match, NULL, NULL, scan_connecting);

int main(void)
{
	int err;
	struct bt_scan_init_param scan_init = {
		.connect_if_match = true,
	};

	printk("\n\n=== Temperature Monitor ===\n\n");

	/* I2C Scanner */
	const struct device *i2c = DEVICE_DT_GET(DT_NODELABEL(i2c1));
	
	if (!device_is_ready(i2c)) {
		printk("ERROR: I2C not ready!\n");
		return 0;
	}
	
	printk("Scanning I2C...\n");
	for (uint8_t addr = 0x20; addr < 0x28; addr++) {
		struct i2c_msg msgs[1];
		uint8_t dst = 0;
		msgs[0].buf = &dst;
		msgs[0].len = 0;
		msgs[0].flags = I2C_MSG_WRITE | I2C_MSG_STOP;
		
		if (i2c_transfer(i2c, &msgs[0], 1, addr) == 0) {
			printk(">>> Found at 0x%02X <<<\n", addr);
		}
	}
	for (uint8_t addr = 0x38; addr < 0x40; addr++) {
		struct i2c_msg msgs[1];
		uint8_t dst = 0;
		msgs[0].buf = &dst;
		msgs[0].len = 0;
		msgs[0].flags = I2C_MSG_WRITE | I2C_MSG_STOP;
		
		if (i2c_transfer(i2c, &msgs[0], 1, addr) == 0) {
			printk(">>> Found at 0x%02X <<<\n", addr);
		}
	}
	printk("Scan done\n\n");

	/* Initialize LCD */
	lcd_init();
	k_msleep(500);

	/* === COMPREHENSIVE LCD TEST === */
	printk("\n>>> LCD TEST 1: Clear <<<\n");
	lcd_clear();
	k_msleep(1000);
	
	printk(">>> LCD TEST 2: All boxes <<<\n");
	lcd_set_cursor(0, 0);
	for (int i = 0; i < 16; i++) {
		lcd_data(0xFF);
	}
	lcd_set_cursor(1, 0);
	for (int i = 0; i < 16; i++) {
		lcd_data(0xFF);
	}
	k_msleep(2000);
	
	printk(">>> LCD TEST 3: Clear again <<<\n");
	lcd_clear();
	k_msleep(1000);
	
	printk(">>> LCD TEST 4: Text test <<<\n");
	lcd_print_at(0, 0, "1234567890123456");
	k_msleep(1000);
	
	lcd_print_at(1, 0, "ABCDEFGHIJKLMNOP");
	k_msleep(2000);
	
	printk(">>> LCD TEST 5: Real message <<<\n");
	lcd_clear();
	k_msleep(500);
	
	lcd_print_at(0, 0, "BME280 Monitor");
	lcd_print_at(1, 0, "Initializing...");
	k_msleep(3000);
	
	printk(">>> LCD TEST COMPLETE <<<\n\n");
	/* === TEST END === */

	/* Initialize LEDs */
	err = dk_leds_init();
	if (err) {
		printk("LED init failed\n");
	}

	/* Enable Bluetooth */
	err = bt_enable(NULL);
	if (err) {
		printk("Bluetooth init failed (err %d)\n", err);
		return 0;
	}
	printk("Bluetooth initialized\n");

	/* Initialize NUS client */
	struct bt_nus_client_init_param nus_init = {
		.cb = {
			.received = nus_data_received,
		}
	};

	err = bt_nus_client_init(&nus_client, &nus_init);
	if (err) {
		printk("NUS Client init failed (err %d)\n", err);
		return 0;
	}

	/* Initialize scanning */
	bt_scan_init(&scan_init);
	bt_scan_cb_register(&scan_cb);

	/* Set scan filter */
	err = bt_scan_filter_add(BT_SCAN_FILTER_TYPE_NAME, "BME280_Sensor");
	if (err) {
		printk("Failed to add scan filter (err %d)\n", err);
	}

	err = bt_scan_filter_enable(BT_SCAN_NAME_FILTER, false);
	if (err) {
		printk("Failed to enable scan filter (err %d)\n", err);
	}

	/* Show scanning on LCD */
	lcd_clear();
	lcd_print_at(0, 0, "Scanning...");

	/* Start scanning */
	err = bt_scan_start(BT_SCAN_TYPE_SCAN_ACTIVE);
	if (err) {
		printk("Scanning failed to start (err %d)\n", err);
		return 0;
	}

	printk("Scanning for BME280_Sensor...\n");

	/* Main loop */
	while (1) {
		k_sleep(K_SECONDS(1));
	}

	return 0;
}