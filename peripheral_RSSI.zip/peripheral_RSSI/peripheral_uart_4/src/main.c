/*
 * BLE Peripheral - Continuous Advertiser for nRF5340DK
 * Shows MAC address for Central configuration
 */

#include <zephyr/kernel.h>
#include <zephyr/bluetooth/bluetooth.h>
#include <zephyr/bluetooth/hci.h>

#define DEVICE_NAME "RSSI_Test_Device"
#define DEVICE_NAME_LEN (sizeof(DEVICE_NAME) - 1)

static const struct bt_data ad[] = {
    BT_DATA(BT_DATA_FLAGS, (BT_LE_AD_GENERAL | BT_LE_AD_NO_BREDR), 1),
    BT_DATA(BT_DATA_NAME_COMPLETE, CONFIG_BT_DEVICE_NAME,
            sizeof(CONFIG_BT_DEVICE_NAME) - 1),
};

int main(void)
{
int err;

err = bt_enable(NULL);
if (err) {
    printk("Bluetooth init failed (err %d)\n", err);
    return 0;
}

printk("Bluetooth initialized\n");

static const struct bt_data ad[] = {
    BT_DATA(BT_DATA_FLAGS, (BT_LE_AD_GENERAL | BT_LE_AD_NO_BREDR), 1),
    BT_DATA(BT_DATA_NAME_COMPLETE, CONFIG_BT_DEVICE_NAME,
            sizeof(CONFIG_BT_DEVICE_NAME) - 1),
};

err = bt_le_adv_start(BT_LE_ADV_CONN, ad, ARRAY_SIZE(ad), NULL, 0);

if (err) {
    printk("Advertising failed (err %d)\n", err);
} else {
    printk("Advertising started\n");
}
	if (err) {
		printk("ERROR: Bluetooth init failed (err %d)\n", err);
		return 0;
	}

	printk("✓ Bluetooth initialized\n\n");

	/* Get MAC address */
	bt_addr_le_t addr = {0};
	size_t count = 1;
	
	bt_id_get(&addr, &count);
char addr_str[BT_ADDR_LE_STR_LEN];

bt_addr_le_to_str(&addr, addr_str, sizeof(addr_str));
	
	printk("╔════════════════════════════════════════╗\n");
	printk("║  PERIPHERAL MAC ADDRESS                ║\n");
	printk("╠════════════════════════════════════════╣\n");
	printk("║                                        ║\n");
	printk("║  %s                   ║\n", addr_str);
	printk("║                                        ║\n");
	printk("╚════════════════════════════════════════╝\n\n");
	
	printk("⚠️  IMPORTANT: Copy this MAC address!\n");
	printk("   Update it in Central's main.c:\n");
	printk("   #define TARGET_MAC \"%s\"\n\n", addr_str);

	/* Start advertising */

	if (err) {
		printk("ERROR: Advertising failed (err %d)\n", err);
		return 0;
	}

	printk("✓ Advertising started\n");
	printk("✓ Device Name: %s\n", DEVICE_NAME);
	printk("✓ Status: BROADCASTING\n\n");
	printk("════════════════════════════════════════\n");
	printk("Ready for Central to scan!\n");
	printk("════════════════════════════════════════\n\n");

	/* Keep advertising */
	uint32_t counter = 0;
	while (1) {
		k_sleep(K_SECONDS(30));
		counter++;
		printk("[%u] Still advertising... [%s]\n", counter, addr_str);
	}

	return 0;
}