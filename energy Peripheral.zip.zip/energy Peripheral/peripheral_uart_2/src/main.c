/*
 * BME280 Temperature Sensor Peripheral with Energy Measurement
 */
#include <zephyr/kernel.h>
#include <zephyr/device.h>
#include <zephyr/drivers/sensor.h>

#include <zephyr/bluetooth/bluetooth.h>
#include <zephyr/bluetooth/uuid.h>
#include <zephyr/bluetooth/gatt.h>

#include <bluetooth/services/nus.h>
#include <dk_buttons_and_leds.h>

#include <stdio.h>
#include <string.h>

#include <zephyr/logging/log.h>

LOG_MODULE_REGISTER(bme280_ble, LOG_LEVEL_INF);

/* BME280 */
static const struct device *bme280 = DEVICE_DT_GET(DT_ALIAS(bme280));

/* BLE */
static struct bt_conn *current_conn;

#define DEVICE_NAME CONFIG_BT_DEVICE_NAME
#define DEVICE_NAME_LEN (sizeof(DEVICE_NAME) - 1)
#define CON_STATUS_LED DK_LED2

/* Energy measurement config */
#define SENSOR_CURRENT_MA 1      /* BME280 @ 3.3V: ~1mA during measurement */
#define TX_CURRENT_MA 10         /* nRF5340 BLE TX: ~10mA */
#define SLEEP_CURRENT_UA 5       /* nRF5340 deep sleep: ~5µA */
#define VOLTAGE_V 3.3            /* Supply voltage 3.3V */

/* Advertising */
static const struct bt_data ad[] = {
	BT_DATA_BYTES(BT_DATA_FLAGS, (BT_LE_AD_GENERAL | BT_LE_AD_NO_BREDR)),
	BT_DATA(BT_DATA_NAME_COMPLETE, DEVICE_NAME, DEVICE_NAME_LEN),
};

static const struct bt_data sd[] = {
	BT_DATA_BYTES(BT_DATA_UUID128_ALL, BT_UUID_NUS_VAL),
};

/* Connection callbacks */
static void connected(struct bt_conn *conn, uint8_t err)
{
	if (err) {
		LOG_ERR("Connection failed (err %d)", err);
		return;
	}

	current_conn = bt_conn_ref(conn);
	dk_set_led_on(CON_STATUS_LED);
	LOG_INF("Connected");
}

static void disconnected(struct bt_conn *conn, uint8_t reason)
{
	if (current_conn) {
		bt_conn_unref(current_conn);
		current_conn = NULL;
		dk_set_led_off(CON_STATUS_LED);
	}
	LOG_INF("Disconnected (reason %d)", reason);
}

BT_CONN_CB_DEFINE(conn_callbacks) = {
	.connected = connected,
	.disconnected = disconnected,
};

/* NUS callback */
static struct bt_nus_cb nus_cb;

/* Read Temperature */
static int read_temperature(float *temp)
{
	struct sensor_value val;

	if (!device_is_ready(bme280)) {
		return -1;
	}

	if (sensor_sample_fetch(bme280)) {
		return -1;
	}

	if (sensor_channel_get(bme280, SENSOR_CHAN_AMBIENT_TEMP, &val)) {
		return -1;
	}

	*temp = val.val1 + val.val2 / 1000000.0f;
	return 0;
}

/* Send Temperature with Energy Measurement */
static void send_temperature(void)
{
	float temp;
	char buffer[32];
	int ret;
	int64_t t_start, t_end;
	uint32_t time_us;
	uint32_t energy_uJ;

	/* ========== SENSOR MEASUREMENT ========== */
	printk("\n--- Sensor Read Start ---\n");
	
	t_start = k_cycle_get_32();
	
	ret = read_temperature(&temp);
	
	t_end = k_cycle_get_32();
	
	if (ret != 0) {
		printk("ERROR: Sensor read failed\n");
		return;
	}
	
	time_us = k_cyc_to_us_floor32(t_end - t_start);
	
	/* Energy = Power × Time = (V × I) × Time */
	/* E(µJ) = V(V) × I(mA) × Time(µs) / 1000 */
	energy_uJ = (uint32_t)((VOLTAGE_V * SENSOR_CURRENT_MA * time_us) / 1000);
	
	printk("Sensor time: %u us\n", time_us);
	printk("Sensor energy: %u uJ\n", energy_uJ);
	
	/* Format temperature */
	int t_int = (int)temp;
	int t_frac = (int)((temp - t_int) * 100);
	if (t_frac < 0) t_frac = -t_frac;
	
	snprintf(buffer, sizeof(buffer), "TEMP:%d.%02d\r\n", t_int, t_frac);
	
	/* ========== BLE TRANSMISSION ========== */
	if (!current_conn) {
		printk("Not connected - skipping TX\n");
		return;
	}
	
	printk("--- BLE TX Start ---\n");
	
	t_start = k_cycle_get_32();
	
	ret = bt_nus_send(current_conn, buffer, strlen(buffer));
	
	t_end = k_cycle_get_32();
	
	time_us = k_cyc_to_us_floor32(t_end - t_start);
	
	/* TX Energy calculation */
	energy_uJ = (uint32_t)((VOLTAGE_V * TX_CURRENT_MA * time_us) / 1000);
	
	if (ret == 0) {
		printk("TX time: %u us\n", time_us);
		printk("TX energy: %u uJ\n", energy_uJ);
		LOG_INF("Sent: %s", buffer);
	} else {
		printk("TX failed (err %d)\n", ret);
	}
}

/* Main */
int main(void)
{
	int err;
	int64_t sleep_start, sleep_end;
	uint32_t sleep_time_us;
	uint32_t sleep_energy_uJ;

	printk("\n\n=== BME280 BLE Peripheral ===\n");
	printk("Energy Measurement Enabled\n\n");

	/* Initialize LEDs */
	err = dk_leds_init();
	if (err) {
		printk("LED init failed\n");
	}

	/* Check sensor */
	if (!device_is_ready(bme280)) {
		printk("ERROR: BME280 not ready!\n");
		printk("Check I2C wiring:\n");
		printk("  VCC -> 3.3V\n");
		printk("  GND -> GND\n");
		printk("  SDA -> P1.02\n");
		printk("  SCL -> P1.03\n");
		return 0;
	}
	printk("BME280 sensor ready\n");

	/* Test read */
	float test_temp;
	if (read_temperature(&test_temp) == 0) {
		int t_int = (int)test_temp;
		int t_frac = (int)((test_temp - t_int) * 100);
		printk("Test reading: %d.%02d C\n\n", t_int, t_frac);
	}

	/* Enable Bluetooth */
	err = bt_enable(NULL);
	if (err) {
		printk("Bluetooth init failed (err %d)\n", err);
		return 0;
	}
	printk("Bluetooth initialized\n");

	/* Initialize NUS */
	err = bt_nus_init(&nus_cb);
	if (err) {
		printk("NUS init failed (err %d)\n", err);
		return 0;
	}

	/* Start advertising */
	err = bt_le_adv_start(BT_LE_ADV_CONN, ad, ARRAY_SIZE(ad), sd, ARRAY_SIZE(sd));
	if (err) {
		printk("Advertising failed (err %d)\n", err);
		return 0;
	}

	printk("Advertising started\n");
	printk("Device name: %s\n", DEVICE_NAME);
	printk("Waiting for connection...\n\n");

	/* Main loop with sleep energy measurement */
	while (1) {
		/* Send temperature */
		send_temperature();

		/* ========== SLEEP ENERGY MEASUREMENT ========== */
		printk("--- Sleep Start (10s) ---\n");
		
		sleep_start = k_cycle_get_32();
		
		k_sleep(K_SECONDS(10));
		
		sleep_end = k_cycle_get_32();
		
		sleep_time_us = k_cyc_to_us_floor32(sleep_end - sleep_start);
		
		/* Sleep Energy: E(µJ) = V × I(µA) × Time(µs) / 1000000 */
		sleep_energy_uJ = (uint32_t)((VOLTAGE_V * SLEEP_CURRENT_UA * sleep_time_us) / 1000000);
		
		printk("Sleep time: %u us (%u ms)\n", sleep_time_us, sleep_time_us / 1000);
		printk("Sleep energy: %u uJ\n", sleep_energy_uJ);
		printk("--- Sleep End ---\n\n");
		
		/* Print total cycle energy */
		printk("=================================\n");
		printk("Energy per 10-second cycle:\n");
		printk("  Sensor: ~%u uJ\n", (uint32_t)((VOLTAGE_V * SENSOR_CURRENT_MA * 100) / 1000));
		printk("  TX:     ~%u uJ\n", (uint32_t)((VOLTAGE_V * TX_CURRENT_MA * 500) / 1000));
		printk("  Sleep:  ~%u uJ\n", sleep_energy_uJ);
		printk("=================================\n\n");
	}

	return 0;
}