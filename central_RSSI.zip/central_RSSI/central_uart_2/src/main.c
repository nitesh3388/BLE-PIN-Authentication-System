/*
 * BLE Central - Fixed for nRF5340DK
 * Solves "Controller unresponsive (err -11)" error
 */

#include <zephyr/kernel.h>
#include <zephyr/device.h>
#include <zephyr/drivers/gpio.h>
#include <zephyr/bluetooth/bluetooth.h>
#include <zephyr/bluetooth/hci.h>
#include <math.h>

/* ═══════════════ CONFIGURATION ═══════════════ */

#define TARGET_MAC "EA:20:B2:7E:FD:30"  /* ← Update this */

#define MEASURED_POWER -59
#define PATH_LOSS_EXPONENT 2.5
#define SCAN_DURATION_SEC 3

/* ═══════════════ BUTTON SETUP ═══════════════ */

#define SW0_NODE DT_ALIAS(sw0)

#if !DT_NODE_HAS_STATUS(SW0_NODE, okay)
#error "Button sw0 not available"
#endif

static const struct gpio_dt_spec button = GPIO_DT_SPEC_GET_OR(SW0_NODE, gpios, {0});
static struct gpio_callback button_cb_data;

/* ═══════════════ STATE & WORK QUEUES ═══════════════ */

static bool scanning = false;
static bool target_found = false;
static int8_t target_rssi = 0;

/* CRITICAL: Use work queues to defer BLE operations from ISR */
static struct k_work_delayable scan_stop_work;
static struct k_work scan_start_work;  /* ← NEW: Start scan work */

/* ═══════════════ HELPER FUNCTIONS ═══════════════ */

static bool parse_mac_address(const char *mac_str, bt_addr_le_t *addr)
{
	unsigned int val[6];
	int ret;

	ret = sscanf(mac_str, "%02X:%02X:%02X:%02X:%02X:%02X",
		     &val[5], &val[4], &val[3], &val[2], &val[1], &val[0]);

	if (ret != 6) {
		return false;
	}

	for (int i = 0; i < 6; i++) {
		addr->a.val[i] = (uint8_t)val[i];
	}
	
	addr->type = BT_ADDR_LE_RANDOM;
	return true;
}

static bool mac_match(const bt_addr_le_t *addr1, const bt_addr_le_t *addr2)
{
	return memcmp(addr1->a.val, addr2->a.val, 6) == 0;
}

static const char* distance_category(float distance)
{
	if (distance < 0.5) return "Touching";
	else if (distance < 1.5) return "Very Close";
	else if (distance < 3.0) return "Close";
	else if (distance < 7.0) return "Medium";
	else if (distance < 15.0) return "Far";
	else return "Very Far";
}

static float calculate_distance(int8_t rssi)
{
	float ratio = (MEASURED_POWER - rssi) / (10.0 * PATH_LOSS_EXPONENT);
	return pow(10.0, ratio);
}

static void display_results(void)
{
	printk("\n════════════════════════════════════════\n");
	
	if (!target_found) {
		printk("  ❌ TARGET NOT FOUND\n");
		printk("════════════════════════════════════════\n");
		printk("  MAC: %s\n\n", TARGET_MAC);
		printk("  Possible Reasons:\n");
		printk("  • Peripheral is OFF\n");
		printk("  • Out of range\n");
		printk("  • Wrong MAC address\n");
	} else {
		float distance = calculate_distance(target_rssi);
		int dist_cm = (int)(distance * 100);
		
		printk("  ✓ TARGET FOUND\n");
		printk("════════════════════════════════════════\n");
		printk("  MAC: %s\n\n", TARGET_MAC);
		printk("  📡 RSSI:     %4d dBm\n", target_rssi);
		printk("  📏 Distance: %d.%02d m (%d cm)\n", 
		       (int)distance, (int)((distance - (int)distance) * 100), dist_cm);
		printk("  📍 Category: %s\n", distance_category(distance));
	}
	
	printk("════════════════════════════════════════\n");
	printk("\n💡 Press SW0 to scan again\n\n");
}

/* ═══════════════ BLE SCAN CALLBACKS ═══════════════ */

static void scan_recv(const struct bt_le_scan_recv_info *info,
		      struct net_buf_simple *buf)
{
	char addr_str[BT_ADDR_LE_STR_LEN];
	bt_addr_le_t target_addr;

	if (!scanning) {
		return;
	}

	if (!parse_mac_address(TARGET_MAC, &target_addr)) {
		return;
	}

	bt_addr_le_to_str(info->addr, addr_str, sizeof(addr_str));
	printk("  Found: %s  RSSI: %4d dBm\n", addr_str, info->rssi);

	if (mac_match(info->addr, &target_addr)) {
		target_found = true;
		target_rssi = info->rssi;
		printk("  >>> TARGET MATCHED! <<<\n");
	}
}

static struct bt_le_scan_cb scan_callbacks = {
	.recv = scan_recv,
};

/* ═══════════════ SCAN CONTROL - FIXED ═══════════════ */

/* CRITICAL FIX: Scan stop handler - runs in workqueue context */
static void scan_stop_handler(struct k_work *work)
{
	int err;

	printk("\n⏱️  Scan completed, stopping...\n");

	/* Safe to call BLE operations here (not in ISR) */
	err = bt_le_scan_stop();
	if (err && err != -EALREADY) {
		printk("   ⚠️  Stop scan warning (err %d)\n", err);
	} else {
		printk("   ✓ Scan stopped\n");
	}

	scanning = false;
	display_results();
}

/* CRITICAL FIX: Scan start handler - runs in workqueue context */
static void scan_start_handler(struct k_work *work)
{
	int err;
	struct bt_le_scan_param scan_param = {
		.type       = BT_LE_SCAN_TYPE_ACTIVE,
		.options    = BT_LE_SCAN_OPT_NONE,
		.interval   = BT_GAP_SCAN_FAST_INTERVAL,
		.window     = BT_GAP_SCAN_FAST_WINDOW,
	};

	if (scanning) {
		printk("⚠️  Already scanning\n");
		return;
	}

	printk("\n════════════════════════════════════════\n");
	printk("  🔍 STARTING SCAN\n");
	printk("════════════════════════════════════════\n");
	printk("  Target: %s\n", TARGET_MAC);
	printk("  Duration: %d seconds\n", SCAN_DURATION_SEC);
	printk("════════════════════════════════════════\n\n");

	target_found = false;
	target_rssi = 0;

	/* Safe to call BLE operations here (workqueue context) */
	err = bt_le_scan_start(&scan_param, NULL);
	if (err) {
		printk("❌ ERROR: Scan start failed (err %d)\n", err);
		
		/* Debug error codes */
		if (err == -EAGAIN) {
			printk("   Reason: Controller busy (EAGAIN)\n");
			printk("   Try again in a moment\n");
		} else if (err == -EALREADY) {
			printk("   Reason: Already scanning\n");
		} else {
			printk("   Unexpected error code\n");
		}
		return;
	}

	scanning = true;
	printk("✓ Scan started successfully\n\n");

	/* Schedule scan stop */
	k_work_schedule(&scan_stop_work, K_SECONDS(SCAN_DURATION_SEC));
}

/* ═══════════════ BUTTON HANDLER - FIXED ═══════════════ */

/* CRITICAL FIX: Button ISR only schedules work, no BLE calls */
static void button_pressed(const struct device *dev, 
			   struct gpio_callback *cb, uint32_t pins)
{
	/* DO NOT call BLE functions here - we're in ISR context! */
	
	printk("\n🔘 Button pressed\n");
	
	/* Cancel any pending operations */
	k_work_cancel_delayable(&scan_stop_work);
	
	/* Stop current scan if running */
	if (scanning) {
		printk("   Stopping current scan...\n");
		bt_le_scan_stop();  /* This is safe to call from ISR */
		scanning = false;
		k_msleep(100);  /* Small delay */
	}
	
	/* Schedule scan start work (deferred to workqueue) */
	k_work_submit(&scan_start_work);
}

/* ═══════════════ BUTTON INIT ═══════════════ */

static int button_init(void)
{
	int ret;

	if (!device_is_ready(button.port)) {
		printk("❌ Button device not ready\n");
		return -ENODEV;
	}

	ret = gpio_pin_configure_dt(&button, GPIO_INPUT);
	if (ret != 0) {
		printk("❌ Pin configure failed (err %d)\n", ret);
		return ret;
	}

	ret = gpio_pin_interrupt_configure_dt(&button, GPIO_INT_EDGE_TO_ACTIVE);
	if (ret != 0) {
		printk("❌ Interrupt config failed (err %d)\n", ret);
		return ret;
	}

	gpio_init_callback(&button_cb_data, button_pressed, BIT(button.pin));
	gpio_add_callback(button.port, &button_cb_data);
	
	printk("✓ Button SW0 configured (pin %d)\n", button.pin);

	return 0;
}

/* ═══════════════ MAIN ═══════════════ */

int main(void)
{
	int err;

	printk("\n\n╔════════════════════════════════════════╗\n");
	printk("║  BLE CENTRAL - RSSI SCANNER            ║\n");
	printk("║  nRF5340DK - FIXED VERSION             ║\n");
	printk("╚════════════════════════════════════════╝\n\n");

	/* CRITICAL: Initialize work queues BEFORE bt_enable */
	k_work_init_delayable(&scan_stop_work, scan_stop_handler);
	k_work_init(&scan_start_work, scan_start_handler);
	
	printk("✓ Work queues initialized\n");

	/* Enable Bluetooth */
	err = bt_enable(NULL);
	if (err) {
		printk("❌ Bluetooth init failed (err %d)\n", err);
		return 0;
	}
	printk("✓ Bluetooth initialized\n");

	/* Small delay for controller to stabilize */
	k_msleep(100);

	/* Register scan callbacks */
	bt_le_scan_cb_register(&scan_callbacks);
	printk("✓ Scan callbacks registered\n");

	/* Initialize button */
	err = button_init();
	if (err) {
		printk("❌ Button init failed (err %d)\n", err);
		return 0;
	}

	printk("\n════════════════════════════════════════\n");
	printk("  ✅ SYSTEM READY\n");
	printk("════════════════════════════════════════\n");
	printk("  Target: %s\n", TARGET_MAC);
	printk("  Button: SW0 (Button 1)\n");
	printk("  Scan:   %d seconds\n", SCAN_DURATION_SEC);
	printk("════════════════════════════════════════\n\n");
	printk("💡 Press SW0 to start!\n\n");

	/* Main loop */
	while (1) {
		k_sleep(K_SECONDS(1));
	}

	return 0;
}